let carrinho = 0;

// Se o HTML e o servidor Flask estiverem no mesmo host/proxy, troque por "/api/cerebro".
const API_CEREBRO_URL = "http://127.0.0.1:5000/api/cerebro";

function comprar(valor, nomeProduto) {
    carrinho += valor;
    document.getElementById("valor-total").innerText = carrinho.toFixed(2);
    const aviso = `${nomeProduto} adicionado ao carrinho`;
    adicionarMensagemRobo(aviso);
    falar(aviso);
}

function alternarTema() {
    document.body.classList.remove("sith-mode");
    document.body.classList.toggle("light-mode");
    const botao = document.getElementById("btn-tema");
    const claro = document.body.classList.contains("light-mode");
    botao.textContent = claro ? "🌙 Mudar para Escuro" : "☀️ Mudar para Claro";
}

function alternarChat() {
    const chat = document.getElementById("chat-container");
    const aberto = getComputedStyle(chat).display !== "none";
    chat.style.display = aberto ? "none" : "flex";
    if (!aberto) document.getElementById("user-input").focus();
}

function adicionarMensagem(texto, tipo = "bot") {
    const chatMessages = document.getElementById("chat-messages");
    const div = document.createElement("div");
    div.className = `message ${tipo === "user" ? "user-message" : "bot-message"}`;
    div.textContent = texto;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    return div;
}

function adicionarMensagemRobo(texto) {
    return adicionarMensagem(texto, "bot");
}

async function enviarMensagem() {
    const inputField = document.getElementById("user-input");
    const textoUsuario = inputField.value.trim();
    if (!textoUsuario) return;

    adicionarMensagem(textoUsuario, "user");
    inputField.value = "";

    const mensagemTemporaria = adicionarMensagemRobo("Consultando servidor...");

    try {
        const resposta = await fetch(API_CEREBRO_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ mensagem: textoUsuario })
        });

        if (!resposta.ok) {
            throw new Error(`HTTP ${resposta.status}`);
        }

        const dados = await resposta.json();
        mensagemTemporaria.remove();
        adicionarMensagemRobo(dados.resposta_agente);
        if (dados.comando_tela === "ativar_lado_sombrio") {
            document.body.classList.remove("light-mode");
            document.body.classList.add("sith-mode");
            const botaoTema = document.getElementById("btn-tema");
            if (botaoTema) botaoTema.textContent = "☀️ Voltar ao tema normal";
        }

        if (dados.comando_tela === "desativar_lado_sombrio") {
            document.body.classList.remove("sith-mode", "light-mode");
            const botaoTema = document.getElementById("btn-tema");
            if (botaoTema) botaoTema.textContent = "☀️ Mudar para Claro";
        }

        // Troca o modo ANTES de sintetizar a resposta.
        falar(dados.resposta_agente);

        if (dados.comando_tela === "abrir_whatsapp") {
            const numeroWhatsApp = "5512991916767";
            const msgPronta = "Vim pelo robô. Tive um problema e preciso solucioná-lo!!";
            const linkWhatsApp = `https://wa.me/${numeroWhatsApp}?text=${encodeURIComponent(msgPronta)}`;
            setTimeout(() => window.open(linkWhatsApp, "_blank", "noopener,noreferrer"), 12000);
        }
    } catch (erro) {
        console.error("Falha ao consultar o servidor:", erro);
        mensagemTemporaria.remove();
        const errorMsg = "Erro de conexão com o servidor.";
        adicionarMensagemRobo(errorMsg);
        falar(errorMsg);
    }
}

// A Web Speech API não expõe o áudio sintetizado ao Web Audio API.
// Portanto o efeito grátis é uma camada sonora sintetizada em paralelo,
// e não um filtro aplicado diretamente à voz do navegador.
let audioSithContext = null;
let efeitoSithAtual = null;
let tokenFala = 0;

function pararEfeitoSith() {
    if (!efeitoSithAtual) return;
    try { efeitoSithAtual.stop(); } catch (erro) { console.debug(erro); }
    efeitoSithAtual = null;
}

function iniciarEfeitoSith() {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;
    try {
        audioSithContext ||= new AudioContextClass();
        const ctx = audioSithContext;
        if (ctx.state === "suspended") ctx.resume().catch(() => {});
        const oscilador = ctx.createOscillator();
        const modulador = ctx.createOscillator();
        const ganhoModulador = ctx.createGain();
        const filtro = ctx.createBiquadFilter();
        const volume = ctx.createGain();
        oscilador.type = "sawtooth";
        oscilador.frequency.value = 57;
        modulador.type = "sine";
        modulador.frequency.value = 5.5;
        ganhoModulador.gain.value = 9;
        filtro.type = "lowpass";
        filtro.frequency.value = 170;
        volume.gain.value = 0.0001;
        modulador.connect(ganhoModulador);
        ganhoModulador.connect(oscilador.frequency);
        oscilador.connect(filtro);
        filtro.connect(volume);
        volume.connect(ctx.destination);
        const agora = ctx.currentTime;
        volume.gain.setTargetAtTime(0.055, agora, 0.15);
        oscilador.start();
        modulador.start();
        let parado = false;
        efeitoSithAtual = { stop() {
            if (parado) return;
            parado = true;
            volume.gain.setTargetAtTime(0.0001, ctx.currentTime, 0.12);
            try { oscilador.stop(ctx.currentTime + 0.65); modulador.stop(ctx.currentTime + 0.65); } catch (_) {}
            setTimeout(() => {
                try { oscilador.disconnect(); modulador.disconnect(); ganhoModulador.disconnect(); filtro.disconnect(); volume.disconnect(); } catch (_) {}
            }, 800);
        }};
    } catch (erro) {
        console.warn("Efeito Sith indisponível:", erro);
    }
}

function falar(texto) {
    if (!( "speechSynthesis" in window)) return;
    const token = ++tokenFala;
    window.speechSynthesis.cancel();
    pararEfeitoSith();
    const modoSith = document.body.classList.contains("sith-mode");
    const fala = new SpeechSynthesisUtterance(String(texto || ""));
    const vozes = window.speechSynthesis.getVoices().filter(v => v.lang.toLowerCase().startsWith("pt"));
    const preferida = vozes.find(v => /antonio|antônio|daniel|francisco/i.test(v.name));
    fala.voice = preferida || vozes.find(v => v.lang.toLowerCase() === "pt-br") || vozes[0] || null;
    fala.lang = "pt-BR";
    fala.rate = modoSith ? 0.70 : 1.04;
    fala.pitch = modoSith ? 0.30 : 1.12;
    fala.volume = 1;
    fala.onstart = () => { if (modoSith && token === tokenFala) iniciarEfeitoSith(); };
    const finalizar = () => { if (token === tokenFala) pararEfeitoSith(); };
    fala.onend = finalizar;
    fala.onerror = finalizar;
    window.speechSynthesis.speak(fala);
}

function ouvirCliente() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        adicionarMensagemRobo("Seu navegador não oferece reconhecimento de voz neste modo.");
        return;
    }

    const reconhecimento = new SpeechRecognition();
    const botao = document.getElementById("btn-mic");
    reconhecimento.lang = "pt-BR";
    reconhecimento.interimResults = false;
    reconhecimento.maxAlternatives = 1;

    reconhecimento.onstart = () => botao.classList.add("ouvindo");
    reconhecimento.onend = () => botao.classList.remove("ouvindo");
    reconhecimento.onerror = () => botao.classList.remove("ouvindo");
    reconhecimento.onresult = (evento) => {
        document.getElementById("user-input").value = evento.results[0][0].transcript;
        enviarMensagem();
    };
    reconhecimento.start();
}

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("user-input")?.addEventListener("keydown", (evento) => {
        if (evento.key === "Enter") enviarMensagem();
    });
});
